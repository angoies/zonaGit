# Ejemplos

## 1. MarkDown

* [Esquema](./markdown/mapa.md)
* [Slides](./markdown/slides.md)

## 2. YAML

* [DevOps](./yaml/ci_cd_todo.yml)
* [Docker](./yaml/docker-compose.yml)
* [Docker WordPress](./yaml/docker-compose_WP.yml)
* [Ejemplo](./yaml/example.yml)
* [mkdocs](./yaml/mkdocs.yml)
* [Tutorial](./yaml/learnyaml-es.yaml)

## 3. JSON

Ejemplo 01:

* [HTML](./json_api/index.html)
* [JS](./json_api/app.js)

Ejemplo 02:

* [HTML](./json_api_swapi/index.html)
* [JS](./json_api_swapi/index.html)